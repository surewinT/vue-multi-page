<template>
  <div class="">这是页面1</div>
</template>

<script>
export default {
  prop: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

<style lang="scss"></style>
