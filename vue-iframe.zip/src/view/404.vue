<!--
 * @Date: 2022-05-19 15:45:28
 * @Author: surewinT 840325271@qq.com
 * @LastEditTime: 2022-05-19 15:51:06
 * @LastEditors: surewinT 840325271@qq.com
 * @Description:
-->

<template>
  <div class="">404,找不到您的页面</div>
</template>

<script>
export default {
  components: {},
  props: [],
  data() {
    return {};
  },
  mounted() {},
  watch: {},
  methods: {},
};
</script>

<style lang='scss' scoped>
</style>