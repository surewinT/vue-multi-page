<!--
 * @Date: 2022-05-19 10:54:03
 * @Author: surewinT 840325271@qq.com
 * @LastEditTime: 2022-05-23 00:14:18
 * @LastEditors: surewinT 840325271@qq.com
 * @Description:
-->

<template>
  <div class="">这是页面2</div>
</template>

<script>
export default {
  components: {},
  props: [],
  data() {
    return {};
  },
  mounted() {},
  watch: {},
  methods: {},
};
</script>

<style lang="scss" scoped></style>
