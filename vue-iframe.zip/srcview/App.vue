<!--
 * @Date: 2022-05-17 15:59:52
 * @Author: surewinT 840325271@qq.com
 * @LastEditTime: 2022-05-23 00:16:28
 * @LastEditors: surewinT 840325271@qq.com
 * @Description: 
-->

<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
  mounted() {},
};
</script>

<style></style>
