<!--
 * @Date: 2022-05-19 10:54:03
 * @Author: surewinT 840325271@qq.com
 * @LastEditTime: 2022-05-23 00:15:23
 * @LastEditors: surewinT 840325271@qq.com
 * @Description: 预览页面1
-->

<template>
  <div class="">
    <el-divider content-position="left">预览组件1</el-divider>
    <div style="text-align:center">
      <el-button type="primary">按钮</el-button>
      <el-button type="success">按钮</el-button>
      <el-button type="warning">按钮</el-button>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  props: [],
  data() {
    return {};
  },
  mounted() {},
  watch: {},
  methods: {},
};
</script>

<style lang="scss" scoped></style>
